/* Program of sorting using insertion sort */
#include <iostream.h>
#include <conio.h>
#define MAX 20

void main()
{
	clrscr();
	int arr[MAX],i,j,k,n;
	cout<<"\n Enter the number of elements : ";
	cin>>n;
	for (i = 0; i < n; i++)
	{
		cout<<"Enter "<<i+1<<" element";
		cin>>arr[i];
	}
	cout<<"Unsorted list is :\n";
	for (i = 0; i < n; i++)
		cout<<arr[i];
	cout<<"\n";
	/*Insertion sort*/
	for(j=1;j<n;j++)
	{
		k=arr[j]; /*k is to be inserted at proper place*/
		for(i=j-1;i>=0 && k<arr[i];i--)
			arr[i+1]=arr[i];
		arr[i+1]=k;
		cout<<"Pass "<<j<<" Element inserted in proper place:"<<k;
		for (i = 0; i < n; i++)
			cout<<arr[i];
		cout<<"\n";
	}
	cout<<"Sorted list is :\n";
	for (i = 0; i < n; i++)
		cout<<arr[i];
	cout<<"\n";
	getch();
}/*End of main()*/



